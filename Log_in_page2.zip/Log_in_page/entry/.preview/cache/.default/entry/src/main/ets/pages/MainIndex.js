/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import router from '@ohos:router';
import MainModel from '@bundle:com.example.log_in_page/entry/ets/viewmodel/MainViewModel2';
import ClockArea from '@bundle:com.example.log_in_page/entry/ets/view/Main/ClockArea';
import AlarmList from '@bundle:com.example.log_in_page/entry/ets/view/Main/AlarmList';
class MainIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.mainModel = MainModel.instant;
        this.__alarmItems = new ObservedPropertyObjectPU(new Array(), this, "alarmItems");
        this.__isAuth = new ObservedPropertySimplePU(false, this, "isAuth");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.mainModel !== undefined) {
            this.mainModel = params.mainModel;
        }
        if (params.alarmItems !== undefined) {
            this.alarmItems = params.alarmItems;
        }
        if (params.isAuth !== undefined) {
            this.isAuth = params.isAuth;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__alarmItems.purgeDependencyOnElmtId(rmElmtId);
        this.__isAuth.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__alarmItems.aboutToBeDeleted();
        this.__isAuth.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get alarmItems() {
        return this.__alarmItems.get();
    }
    set alarmItems(newValue) {
        this.__alarmItems.set(newValue);
    }
    get isAuth() {
        return this.__isAuth.get();
    }
    set isAuth(newValue) {
        this.__isAuth.set(newValue);
    }
    /*
     aboutToAppear() {
        let that = this;
        that.mainModel.queryAlarmsTasker((alarms: Array<AlarmItem>) => {
          that.alarmItems = alarms;
        })
      }
      */
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/MainIndex.ets(41:5)");
            Column.width("100%");
            Column.height("100%");
            Column.backgroundColor({ "id": 16777462, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("闹钟");
            Text.debugLine("pages/MainIndex.ets(42:7)");
            Text.height(56);
            Text.textAlign(TextAlign.Start);
            Text.fontSize(24);
            Text.width("100%");
            Text.fontColor({ "id": 16777461, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ bottom: 16 });
            Text.padding({ left: 24 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new ClockArea(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new AlarmList(this, { alarmItems: this.__alarmItems }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/MainIndex.ets(57:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/MainIndex.ets(59:7)");
            Button.backgroundColor({ "id": 16777480, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.width(48);
            Button.height(48);
            Button.margin({
                bottom: 24,
                top: 24
            });
            Button.onClick(() => {
                router.pushUrl({ url: 'pages/DetailIndex' });
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777486, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Image.debugLine("pages/MainIndex.ets(60:9)");
            Image.objectFit(ImageFit.Fill);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new MainIndex(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=MainIndex.js.map