/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import router from '@ohos:router';
import { CommonConstants } from '@bundle:com.example.log_in_page/entry/ets/common/constants/CommonConstants2';
import AlarmItem from '@bundle:com.example.log_in_page/entry/ets/viewmodel/AlarmItem';
import AlarmSettingItem from '@bundle:com.example.log_in_page/entry/ets/viewmodel/AlarmSettingItem';
import { AlarmSettingType } from '@bundle:com.example.log_in_page/entry/ets/common/constants/AlarmSettingType';
import { DetailConstant } from '@bundle:com.example.log_in_page/entry/ets/common/constants/DetailConstant';
import BackContainer from '@bundle:com.example.log_in_page/entry/ets/view/BackContainer';
import DetailModel from '@bundle:com.example.log_in_page/entry/ets/viewmodel/DetailViewModel';
import DatePickArea from '@bundle:com.example.log_in_page/entry/ets/view/Detail/DatePickArea';
import SettingItem from '@bundle:com.example.log_in_page/entry/ets/view/Detail/SettingItem';
class DetailIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__alarmItem = new ObservedPropertyObjectPU(new AlarmItem(), this, "alarmItem");
        this.addProvidedVar("onAlarmItemChange", this.__alarmItem);
        this.addProvidedVar("alarmItem", this.__alarmItem);
        this.__repeatSettingArr = new ObservedPropertyObjectPU([], this, "repeatSettingArr");
        this.__alarmSettingInfoArr = new ObservedPropertyObjectPU([], this, "alarmSettingInfoArr");
        this.isNow = true;
        this.viewModel = DetailModel.instant;
        this.setInitiallyProvidedValue(params);
        this.declareWatch("alarmItem", this.onAlarmItemChange);
    }
    setInitiallyProvidedValue(params) {
        if (params.alarmItem !== undefined) {
            this.alarmItem = params.alarmItem;
        }
        if (params.repeatSettingArr !== undefined) {
            this.repeatSettingArr = params.repeatSettingArr;
        }
        if (params.alarmSettingInfoArr !== undefined) {
            this.alarmSettingInfoArr = params.alarmSettingInfoArr;
        }
        if (params.isNow !== undefined) {
            this.isNow = params.isNow;
        }
        if (params.viewModel !== undefined) {
            this.viewModel = params.viewModel;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__repeatSettingArr.purgeDependencyOnElmtId(rmElmtId);
        this.__alarmSettingInfoArr.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__alarmItem.aboutToBeDeleted();
        this.__repeatSettingArr.aboutToBeDeleted();
        this.__alarmSettingInfoArr.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get alarmItem() {
        return this.__alarmItem.get();
    }
    set alarmItem(newValue) {
        this.__alarmItem.set(newValue);
    }
    get repeatSettingArr() {
        return this.__repeatSettingArr.get();
    }
    set repeatSettingArr(newValue) {
        this.__repeatSettingArr.set(newValue);
    }
    get alarmSettingInfoArr() {
        return this.__alarmSettingInfoArr.get();
    }
    set alarmSettingInfoArr(newValue) {
        this.__alarmSettingInfoArr.set(newValue);
    }
    aboutToAppear() {
        let params = router.getParams();
        if (params !== undefined) {
            let alarmItem = params.alarmItem;
            if (alarmItem !== undefined) {
                this.isNow = false;
                this.alarmItem = alarmItem;
                this.viewModel.setAlarmDefaultTime(this.alarmItem);
            }
            else {
                this.viewModel.setAlarmDefaultTime();
            }
        }
        else {
            this.viewModel.setAlarmDefaultTime();
        }
        this.initData();
    }
    onAlarmItemChange() {
        this.initData();
    }
    initData() {
        this.repeatSettingArr = [
            new AlarmSettingItem(DetailConstant.DEFAULT_STRING_REPEAT, this.alarmItem.isRepeat ? DetailConstant.DEFAULT_STRING_REPEAT
                : CommonConstants.DEFAULT_STRING_NO_REPEAT, AlarmSettingType.REPEAT)
        ];
        this.alarmSettingInfoArr = [
            new AlarmSettingItem(DetailConstant.DEFAULT_STRING_ALARM_NAME, this.alarmItem.name, AlarmSettingType.ALARM_NAME),
            new AlarmSettingItem(DetailConstant.DEFAULT_STRING_DURATION, this.alarmItem.duration + DetailConstant.DEFAULT_STRING_MINUTE, AlarmSettingType.RING_DURATION),
            new AlarmSettingItem(DetailConstant.DEFAULT_STRING_INTERVAL, this.alarmItem.intervalMinute
                + DetailConstant.DEFAULT_STRING_MINUTE + CommonConstants.DEFAULT_STRING_COMMA
                + this.alarmItem.intervalTimes + DetailConstant.DEFAULT_STRING_TIMES, AlarmSettingType.INTERVAL)
        ];
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/DetailIndex.ets(75:5)");
            Column.backgroundColor({ "id": 16777462, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Column.width(CommonConstants.FULL_LENGTH);
            Column.height(CommonConstants.FULL_LENGTH);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new BackContainer(this, {
                        header: this.isNow ? { "id": 16777408, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } : { "id": 16777435, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" },
                        backImgRes: { "id": 16777360, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" },
                        closer: () => {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Button.createWithChild();
                                Button.debugLine("pages/DetailIndex.ets(80:9)");
                                Button.backgroundColor({ "id": 16777480, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                                Button.width(24);
                                Button.height(24);
                                Button.onClick(() => {
                                    this.viewModel.setAlarmRemind(ObservedObject.GetRawObject(this.alarmItem));
                                    router.back();
                                });
                                if (!isInitialRender) {
                                    Button.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Image.create({ "id": 16777218, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                                Image.debugLine("pages/DetailIndex.ets(81:11)");
                                Image.objectFit(ImageFit.Fill);
                                if (!isInitialRender) {
                                    Image.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                            Button.pop();
                        }
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new DatePickArea(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new SettingItem(this, {
                        settingInfo: this.__repeatSettingArr
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new SettingItem(this, {
                        settingInfo: this.__alarmSettingInfoArr
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/DetailIndex.ets(101:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel({ "id": 16777377, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.debugLine("pages/DetailIndex.ets(103:7)");
            Button.visibility(this.isNow ? Visibility.None : Visibility.Visible);
            Button.width(120);
            Button.height(40);
            Button.fontSize(16);
            Button.fontColor({ "id": 16777475, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.backgroundColor({ "id": 16777463, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.borderRadius(20);
            Button.margin({
                bottom: 24
            });
            Button.onClick(() => {
                this.viewModel.removeAlarmRemind(this.alarmItem.id);
                router.back();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new DetailIndex(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=DetailIndex.js.map