/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import router from '@ohos:router';
import { CommonConstants } from '@bundle:com.example.log_in_page/entry/ets/common/constants/CommonConstants2';
export default class BackContainer extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.header = { "id": 16777408, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" };
        this.backImgRes = { "id": 16777360, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" };
        this.backFunc = undefined;
        this.closer = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.header !== undefined) {
            this.header = params.header;
        }
        if (params.backImgRes !== undefined) {
            this.backImgRes = params.backImgRes;
        }
        if (params.backFunc !== undefined) {
            this.backFunc = params.backFunc;
        }
        if (params.closer !== undefined) {
            this.closer = params.closer;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/BackContainer.ets(28:5)");
            Row.padding({
                left: 24,
                right: 24
            });
            Row.height(56);
            Row.width(CommonConstants.FULL_LENGTH);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("view/BackContainer.ets(29:7)");
            Button.backgroundColor({ "id": 16777480, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.width(24);
            Button.height(24);
            Button.onClick(() => {
                this.backFunc ? this.backFunc() : router.back();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.backImgRes == null ? { "id": 16777452, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } : this.backImgRes);
            Image.debugLine("view/BackContainer.ets(30:9)");
            Image.objectFit(ImageFit.Fill);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.header);
            Text.debugLine("view/BackContainer.ets(39:7)");
            Text.fontSize(20);
            Text.lineHeight(28);
            Text.margin({ left: 16 });
            Text.fontColor({ "id": 16777461, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("view/BackContainer.ets(45:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.closer) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.closer.bind(this)();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=BackContainer.js.map