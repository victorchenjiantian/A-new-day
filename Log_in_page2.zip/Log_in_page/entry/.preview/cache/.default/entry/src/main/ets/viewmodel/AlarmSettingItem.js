/**
 * Alarm setting item information.
 */
export default class AlarmSettingItem {
    constructor(title, content, sType) {
        this.title = title;
        this.content = content;
        this.sType = sType;
    }
}
//# sourceMappingURL=AlarmSettingItem.js.map