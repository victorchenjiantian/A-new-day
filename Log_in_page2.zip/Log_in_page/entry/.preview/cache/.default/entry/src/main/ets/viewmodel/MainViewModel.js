/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import ItemData from '@bundle:com.example.log_in_page/entry/ets/viewmodel/ItemData';
/**
 * Binds data to components and provides interfaces.
 */
export class MainViewModel {
    /**
     * Get swiper image data.
     *
     * @return {Array<Resource>} swiperImages.
     */
    getSwiperImages() {
        let swiperImages = [
            { "id": 16777443, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" },
            { "id": 16777224, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" },
            { "id": 16777446, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" },
            { "id": 16777220, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }
        ];
        return swiperImages;
    }
    /**
     * Get data of the first grid.
     *
     * @return {Array<PageResource>} firstGridData.
     */
    /*  getFirstGridData(): Array<ItemData> {
        let firstGridData: ItemData[] = [
          new ItemData($r('app.string.my_love'), $r('app.media.love')),
          new ItemData($r('app.string.history_record'), $r('app.media.record')),
          new ItemData($r('app.string.message'), $r('app.media.message')),
          new ItemData($r('app.string.shopping_cart'), $r('app.media.shopping')),
          new ItemData($r('app.string.my_goal'), $r('app.media.target')),
          new ItemData($r('app.string.group'), $r('app.media.circle')),
          new ItemData($r('app.string.favorites'), $r('app.media.favorite')),
          new ItemData($r('app.string.recycle_bin'), $r('app.media.recycle'))
        ];
        return firstGridData;
      }*/
    /**
     * Get data of the second grid.
     *
     * @return {Array<PageResource>} secondGridData.
     */
    getSecondGridData() {
        let secondGridData = [
            new ItemData({ "id": 16777400, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777495, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777399, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }),
            new ItemData({ "id": 16777393, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777451, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777398, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }),
            new ItemData({ "id": 16777391, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777453, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777396, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }),
            new ItemData({ "id": 16777392, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777440, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777397, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" })
        ];
        return secondGridData;
    }
    /**
     * Get data of the setting list.
     *
     * @return {Array<PageResource>} settingListData.
     */
    getSettingListData() {
        let settingListData = [
            new ItemData({ "id": 16777430, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777497, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777433, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }),
            new ItemData({ "id": 16777428, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777482, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }),
            new ItemData({ "id": 16777429, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777221, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }),
            new ItemData({ "id": 16777427, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777450, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }),
            new ItemData({ "id": 16777432, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777283, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }),
            new ItemData({ "id": 16777431, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, { "id": 16777363, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" })
        ];
        return settingListData;
    }
}
export default new MainViewModel();
//# sourceMappingURL=MainViewModel.js.map