/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import CommonConstants from '@bundle:com.example.log_in_page/entry/ets/common/constants/CommonConstants';
import mainViewModel from '@bundle:com.example.log_in_page/entry/ets/viewmodel/MainViewModel';
import prompt from '@ohos:promptAction';
import router from '@ohos:router';
export default class Home extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.swiperController = new SwiperController();
        this.timeOutId = -1;
        this.urls = "0";
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.swiperController !== undefined) {
            this.swiperController = params.swiperController;
        }
        if (params.timeOutId !== undefined) {
            this.timeOutId = params.timeOutId;
        }
        if (params.urls !== undefined) {
            this.urls = params.urls;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    start(t) {
        t = "a";
        if (t == "a") {
            this.urls = 'pages/MainIndex';
        }
        /*this.isShowProgress = true;
        if (this.timeOutId === -1) {*/
        prompt.showToast({
            message: "loading......"
        });
        this.timeOutId = setTimeout(() => {
            /*this.isShowProgress = false;
            this.timeOutId = -1;*/
            console.info(`pages/RegisterPage`);
            router.pushUrl({ url: 'pages/MainIndex' }).then(() => {
                console.info('Succeeded in jumping to the second page.');
            }).catch((err) => {
                console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`);
            });
        }, CommonConstants.LOGIN_DELAY_TIME);
        //}
    }
    start1() {
        /*this.isShowProgress = true;
        if (this.timeOutId === -1) {*/
        prompt.showToast({
            message: { "id": 16777437, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }
        });
        this.timeOutId = setTimeout(() => {
            /*this.isShowProgress = false;
            this.timeOutId = -1;*/
            console.info(`pages/RegisterPage`);
            router.pushUrl({ url: 'pages/MainIndex' }).then(() => {
                console.info('Succeeded in jumping to the second page.');
            }).catch((err) => {
                console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`);
            });
        }, CommonConstants.LOGIN_DELAY_TIME);
        //}
    }
    start2() {
        /*this.isShowProgress = true;
        if (this.timeOutId === -1) {*/
        prompt.showToast({
            message: { "id": 16777437, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }
        });
        this.timeOutId = setTimeout(() => {
            /*this.isShowProgress = false;
            this.timeOutId = -1;*/
            console.info(`pages/RegisterPage`);
            router.pushUrl({ url: 'pages/schedule' }).then(() => {
                console.info('Succeeded in jumping to the second page.');
            }).catch((err) => {
                console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`);
            });
        }, CommonConstants.LOGIN_DELAY_TIME);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Scroll.create();
            Scroll.debugLine("view/Home.ets(97:5)");
            Scroll.scrollBarWidth(0);
            Scroll.height(CommonConstants.FULL_PARENT);
            if (!isInitialRender) {
                Scroll.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: CommonConstants.COMMON_SPACE });
            Column.debugLine("view/Home.ets(98:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/Home.ets(99:9)");
            Column.width(CommonConstants.FULL_PARENT);
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777394, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Text.debugLine("view/Home.ets(100:11)");
            Text.fontWeight(FontWeight.Medium);
            Text.fontSize({ "id": 16777335, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Text.margin({ top: { "id": 16777327, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
            Text.padding({ left: { "id": 16777328, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Swiper.create(this.swiperController);
            Swiper.debugLine("view/Home.ets(109:9)");
            Swiper.margin({ top: { "id": 16777305, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
            Swiper.autoPlay(true);
            if (!isInitialRender) {
                Swiper.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const img = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create(img);
                    Image.debugLine("view/Home.ets(111:13)");
                    Image.borderRadius({ "id": 16777304, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
            };
            this.forEachUpdateFunction(elmtId, mainViewModel.getSwiperImages(), forEachItemGenFunction, (img) => JSON.stringify(img.id), false, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Swiper.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            /*Grid() {
              */ /*ForEach(mainViewModel.getFirstGridData(), (item: ItemData) => {
              GridItem() {
                Column() {
                  Image(item.img)
                    .width($r('app.float.home_homeCell_size'))
                    .height($r('app.float.home_homeCell_size'))
                  Text(item.title)
                    .fontSize($r('app.float.little_text_size'))
                    .margin({ top: $r('app.float.home_homeCell_margin') })
                }
              }
            }, (item: ItemData) => JSON.stringify(item))*/ /*
          }*/
            /*.columnsTemplate('1fr 1fr 1fr 1fr')
            .rowsTemplate('1fr 1fr')
            .columnsGap($r('app.float.home_grid_columnsGap'))
            .rowsGap($r('app.float.home_grid_rowGap'))
            .padding({ top: $r('app.float.home_grid_padding'), bottom: $r('app.float.home_grid_padding') })
            .height($r('app.float.home_grid_height'))
            .backgroundColor(Color.White)
            .borderRadius($r('app.float.home_grid_borderRadius'))*/
            Text.create({ "id": 16777384, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Text.debugLine("view/Home.ets(140:9)");
            /*Grid() {
              */ /*ForEach(mainViewModel.getFirstGridData(), (item: ItemData) => {
              GridItem() {
                Column() {
                  Image(item.img)
                    .width($r('app.float.home_homeCell_size'))
                    .height($r('app.float.home_homeCell_size'))
                  Text(item.title)
                    .fontSize($r('app.float.little_text_size'))
                    .margin({ top: $r('app.float.home_homeCell_margin') })
                }
              }
            }, (item: ItemData) => JSON.stringify(item))*/ /*
          }*/
            /*.columnsTemplate('1fr 1fr 1fr 1fr')
            .rowsTemplate('1fr 1fr')
            .columnsGap($r('app.float.home_grid_columnsGap'))
            .rowsGap($r('app.float.home_grid_rowGap'))
            .padding({ top: $r('app.float.home_grid_padding'), bottom: $r('app.float.home_grid_padding') })
            .height($r('app.float.home_grid_height'))
            .backgroundColor(Color.White)
            .borderRadius($r('app.float.home_grid_borderRadius'))*/
            Text.fontSize({ "id": 16777330, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            /*Grid() {
              */ /*ForEach(mainViewModel.getFirstGridData(), (item: ItemData) => {
              GridItem() {
                Column() {
                  Image(item.img)
                    .width($r('app.float.home_homeCell_size'))
                    .height($r('app.float.home_homeCell_size'))
                  Text(item.title)
                    .fontSize($r('app.float.little_text_size'))
                    .margin({ top: $r('app.float.home_homeCell_margin') })
                }
              }
            }, (item: ItemData) => JSON.stringify(item))*/ /*
          }*/
            /*.columnsTemplate('1fr 1fr 1fr 1fr')
            .rowsTemplate('1fr 1fr')
            .columnsGap($r('app.float.home_grid_columnsGap'))
            .rowsGap($r('app.float.home_grid_rowGap'))
            .padding({ top: $r('app.float.home_grid_padding'), bottom: $r('app.float.home_grid_padding') })
            .height($r('app.float.home_grid_height'))
            .backgroundColor(Color.White)
            .borderRadius($r('app.float.home_grid_borderRadius'))*/
            Text.fontWeight(FontWeight.Medium);
            /*Grid() {
              */ /*ForEach(mainViewModel.getFirstGridData(), (item: ItemData) => {
              GridItem() {
                Column() {
                  Image(item.img)
                    .width($r('app.float.home_homeCell_size'))
                    .height($r('app.float.home_homeCell_size'))
                  Text(item.title)
                    .fontSize($r('app.float.little_text_size'))
                    .margin({ top: $r('app.float.home_homeCell_margin') })
                }
              }
            }, (item: ItemData) => JSON.stringify(item))*/ /*
          }*/
            /*.columnsTemplate('1fr 1fr 1fr 1fr')
            .rowsTemplate('1fr 1fr')
            .columnsGap($r('app.float.home_grid_columnsGap'))
            .rowsGap($r('app.float.home_grid_rowGap'))
            .padding({ top: $r('app.float.home_grid_padding'), bottom: $r('app.float.home_grid_padding') })
            .height($r('app.float.home_grid_height'))
            .backgroundColor(Color.White)
            .borderRadius($r('app.float.home_grid_borderRadius'))*/
            Text.width(CommonConstants.FULL_PARENT);
            /*Grid() {
              */ /*ForEach(mainViewModel.getFirstGridData(), (item: ItemData) => {
              GridItem() {
                Column() {
                  Image(item.img)
                    .width($r('app.float.home_homeCell_size'))
                    .height($r('app.float.home_homeCell_size'))
                  Text(item.title)
                    .fontSize($r('app.float.little_text_size'))
                    .margin({ top: $r('app.float.home_homeCell_margin') })
                }
              }
            }, (item: ItemData) => JSON.stringify(item))*/ /*
          }*/
            /*.columnsTemplate('1fr 1fr 1fr 1fr')
            .rowsTemplate('1fr 1fr')
            .columnsGap($r('app.float.home_grid_columnsGap'))
            .rowsGap($r('app.float.home_grid_rowGap'))
            .padding({ top: $r('app.float.home_grid_padding'), bottom: $r('app.float.home_grid_padding') })
            .height($r('app.float.home_grid_height'))
            .backgroundColor(Color.White)
            .borderRadius($r('app.float.home_grid_borderRadius'))*/
            Text.margin({ top: { "id": 16777306, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
            if (!isInitialRender) {
                /*Grid() {
                  */ /*ForEach(mainViewModel.getFirstGridData(), (item: ItemData) => {
                  GridItem() {
                    Column() {
                      Image(item.img)
                        .width($r('app.float.home_homeCell_size'))
                        .height($r('app.float.home_homeCell_size'))
                      Text(item.title)
                        .fontSize($r('app.float.little_text_size'))
                        .margin({ top: $r('app.float.home_homeCell_margin') })
                    }
                  }
                }, (item: ItemData) => JSON.stringify(item))*/ /*
              }*/
                /*.columnsTemplate('1fr 1fr 1fr 1fr')
                .rowsTemplate('1fr 1fr')
                .columnsGap($r('app.float.home_grid_columnsGap'))
                .rowsGap($r('app.float.home_grid_rowGap'))
                .padding({ top: $r('app.float.home_grid_padding'), bottom: $r('app.float.home_grid_padding') })
                .height($r('app.float.home_grid_height'))
                .backgroundColor(Color.White)
                .borderRadius($r('app.float.home_grid_borderRadius'))*/
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        /*Grid() {
          */ /*ForEach(mainViewModel.getFirstGridData(), (item: ItemData) => {
          GridItem() {
            Column() {
              Image(item.img)
                .width($r('app.float.home_homeCell_size'))
                .height($r('app.float.home_homeCell_size'))
              Text(item.title)
                .fontSize($r('app.float.little_text_size'))
                .margin({ top: $r('app.float.home_homeCell_margin') })
            }
          }
        }, (item: ItemData) => JSON.stringify(item))*/ /*
      }*/
        /*.columnsTemplate('1fr 1fr 1fr 1fr')
        .rowsTemplate('1fr 1fr')
        .columnsGap($r('app.float.home_grid_columnsGap'))
        .rowsGap($r('app.float.home_grid_rowGap'))
        .padding({ top: $r('app.float.home_grid_padding'), bottom: $r('app.float.home_grid_padding') })
        .height($r('app.float.home_grid_height'))
        .backgroundColor(Color.White)
        .borderRadius($r('app.float.home_grid_borderRadius'))*/
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Grid.create();
            Grid.debugLine("view/Home.ets(146:9)");
            Grid.width(CommonConstants.FULL_PARENT);
            Grid.height({ "id": 16777302, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Grid.columnsTemplate('1fr 1fr');
            Grid.rowsTemplate('1fr 1fr');
            Grid.columnsGap({ "id": 16777291, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Grid.rowsGap({ "id": 16777295, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Grid.margin({ bottom: { "id": 16777343, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
            if (!isInitialRender) {
                Grid.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const secondItem = _item;
                {
                    const isLazyCreate = true && (Grid.willUseProxy() === true);
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        GridItem.create(deepRenderFunction, isLazyCreate);
                        GridItem.onClick(() => {
                            this.start(secondItem.title);
                        });
                        GridItem.padding({ top: { "id": 16777301, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, left: { "id": 16777301, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
                        GridItem.borderRadius({ "id": 16777289, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                        GridItem.align(Alignment.TopStart);
                        GridItem.backgroundImage(secondItem.img);
                        GridItem.backgroundImageSize(ImageSize.Cover);
                        GridItem.width(CommonConstants.FULL_PARENT);
                        GridItem.height(CommonConstants.FULL_PARENT);
                        GridItem.debugLine("view/Home.ets(148:13)");
                        if (!isInitialRender) {
                            GridItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        GridItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("view/Home.ets(149:15)");
                            Column.alignItems(HorizontalAlign.Start);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(secondItem.title);
                            Text.debugLine("view/Home.ets(151:19)");
                            Text.fontSize({ "id": 16777330, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                            Text.fontWeight(FontWeight.Medium);
                            Text.backgroundColor(Color.White);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(secondItem.others);
                            Text.debugLine("view/Home.ets(156:19)");
                            Text.margin({ top: { "id": 16777300, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
                            Text.fontSize({ "id": 16777309, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                            Text.fontColor({ "id": 16777464, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        GridItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("view/Home.ets(149:15)");
                            Column.alignItems(HorizontalAlign.Start);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(secondItem.title);
                            Text.debugLine("view/Home.ets(151:19)");
                            Text.fontSize({ "id": 16777330, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                            Text.fontWeight(FontWeight.Medium);
                            Text.backgroundColor(Color.White);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(secondItem.others);
                            Text.debugLine("view/Home.ets(156:19)");
                            Text.margin({ top: { "id": 16777300, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
                            Text.fontSize({ "id": 16777309, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                            Text.fontColor({ "id": 16777464, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        GridItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, mainViewModel.getSecondGridData(), forEachItemGenFunction, (secondItem) => JSON.stringify(secondItem), false, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Grid.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("进入");
            Button.debugLine("view/Home.ets(183:9)");
            Button.position({ x: 90, y: 390 });
            Button.onClick(() => {
                this.start1();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("进入");
            Button.debugLine("view/Home.ets(188:9)");
            Button.position({ x: 260, y: 390 });
            Button.onClick(() => {
                this.start2();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
        Scroll.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=Home.js.map