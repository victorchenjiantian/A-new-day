import MainModel from '@bundle:com.example.log_in_page/entry/ets/viewmodel/MainViewModel2';
class MainIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.mainModel = MainModel.instant;
        this.__alarmItems = new ObservedPropertyObjectPU(new Array(), this, "alarmItems");
        this.__isAuth = new ObservedPropertySimplePU(false, this, "isAuth");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.mainModel !== undefined) {
            this.mainModel = params.mainModel;
        }
        if (params.alarmItems !== undefined) {
            this.alarmItems = params.alarmItems;
        }
        if (params.isAuth !== undefined) {
            this.isAuth = params.isAuth;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__alarmItems.purgeDependencyOnElmtId(rmElmtId);
        this.__isAuth.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__alarmItems.aboutToBeDeleted();
        this.__isAuth.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get alarmItems() {
        return this.__alarmItems.get();
    }
    set alarmItems(newValue) {
        this.__alarmItems.set(newValue);
    }
    get isAuth() {
        return this.__isAuth.get();
    }
    set isAuth(newValue) {
        this.__isAuth.set(newValue);
    }
    /*
     aboutToAppear() {
        let that = this;
        that.mainModel.queryAlarmsTasker((alarms: Array<AlarmItem>) => {
          that.alarmItems = alarms;
        })
      }
      */
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // ListIndex.ets
            Row.create();
            Row.debugLine("pages/ListIndex.ets(42:5)");
            // ListIndex.ets
            Row.height(LAYOUT_WIDTH_OR_HEIGHT);
            // ListIndex.ets
            Row.backgroundColor($r('app.color.primaryBgColor'));
            if (!isInitialRender) {
                // ListIndex.ets
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Navigation.create();
            Navigation.debugLine("pages/ListIndex.ets(43:7)");
            Navigation.size({ width: LAYOUT_WIDTH_OR_HEIGHT, height: LAYOUT_WIDTH_OR_HEIGHT });
            Navigation.title(STORE);
            Navigation.titleMode(NavigationTitleMode.Mini);
            if (!isInitialRender) {
                Navigation.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/ListIndex.ets(44:9)");
            Column.width(LAYOUT_WIDTH_OR_HEIGHT);
            Column.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
        Navigation.pop();
        // ListIndex.ets
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new MainIndex(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=ListIndex.js.map