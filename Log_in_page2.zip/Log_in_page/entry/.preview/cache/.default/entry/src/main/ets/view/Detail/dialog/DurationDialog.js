/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { CommonConstants } from '@bundle:com.example.log_in_page/entry/ets/common/constants/CommonConstants2';
import { DetailConstant } from '@bundle:com.example.log_in_page/entry/ets/common/constants/DetailConstant';
import CommonDialog from '@bundle:com.example.log_in_page/entry/ets/view/Detail/dialog/CommonDialog';
export default class DurationDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__alarmItem = this.initializeConsume("alarmItem", "alarmItem");
        this.durations = DetailConstant.RING_DURATION;
        this.controller = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.durations !== undefined) {
            this.durations = params.durations;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__alarmItem.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get alarmItem() {
        return this.__alarmItem.get();
    }
    set alarmItem(newValue) {
        this.__alarmItem.set(newValue);
    }
    setController(ctr) {
        this.controller = ctr;
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create();
            Flex.debugLine("view/Detail/dialog/DurationDialog.ets(29:5)");
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new CommonDialog(this, {
                        title: { "id": 16777420, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" },
                        controller: this.controller,
                        closer: () => {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                ForEach.create();
                                const forEachItemGenFunction = _item => {
                                    const item = _item;
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Row.create();
                                        Row.debugLine("view/Detail/dialog/DurationDialog.ets(35:11)");
                                        Row.width(CommonConstants.FULL_LENGTH);
                                        if (!isInitialRender) {
                                            Row.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Text.create(item + CommonConstants.DEFAULT_STRING_SPACE + DetailConstant.DEFAULT_STRING_MINUTE);
                                        Text.debugLine("view/Detail/dialog/DurationDialog.ets(36:13)");
                                        Text.layoutWeight(CommonConstants.DEFAULT_LAYOUT_WEIGHT);
                                        Text.fontColor({ "id": 16777461, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                                        Text.fontSize(14);
                                        if (!isInitialRender) {
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Text.pop();
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Radio.create({ value: item.toString(), group: DetailConstant.DEFAULT_STRING_GROUP_NAME });
                                        Radio.debugLine("view/Detail/dialog/DurationDialog.ets(40:13)");
                                        Radio.checked(item === this.alarmItem.duration ? true : false);
                                        Radio.height(20);
                                        Radio.width(20);
                                        Radio.onChange(() => {
                                            if (!this.controller) {
                                                return;
                                            }
                                            this.controller.close();
                                            this.alarmItem.duration = item;
                                        });
                                        if (!isInitialRender) {
                                            Radio.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Row.pop();
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Divider.create();
                                        Divider.debugLine("view/Detail/dialog/DurationDialog.ets(54:11)");
                                        Divider.opacity({ "id": 16777254, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                                        Divider.color({ "id": 16777461, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                                        Divider.lineCap(LineCapStyle.Round);
                                        if (!isInitialRender) {
                                            Divider.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                };
                                this.forEachUpdateFunction(elmtId, this.durations, forEachItemGenFunction);
                                if (!isInitialRender) {
                                    ForEach.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                            ForEach.pop();
                        }
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        Flex.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=DurationDialog.js.map