/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { CommonConstants } from '@bundle:com.example.log_in_page/entry/ets/common/constants/CommonConstants2';
import { AlarmSettingType } from '@bundle:com.example.log_in_page/entry/ets/common/constants/AlarmSettingType';
import IntervalDialog from '@bundle:com.example.log_in_page/entry/ets/view/Detail/dialog/IntervalDialog';
import DurationDialog from '@bundle:com.example.log_in_page/entry/ets/view/Detail/dialog/DurationDialog';
import RenameDialog from '@bundle:com.example.log_in_page/entry/ets/view/Detail/dialog/RenameDialog';
import RepeatDialog from '@bundle:com.example.log_in_page/entry/ets/view/Detail/dialog/RepeatDialog';
export default class SettingItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__settingInfo = new SynchedPropertyObjectTwoWayPU(params.settingInfo, this, "settingInfo");
        this.repeatDialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new RepeatDialog(this, {});
                jsDialog.setController(this.repeatDialogController);
                ViewPU.create(jsDialog);
            },
            autoCancel: true
        }, this);
        this.reNameDialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new RenameDialog(this, {});
                jsDialog.setController(this.reNameDialogController);
                ViewPU.create(jsDialog);
            },
            autoCancel: true
        }, this);
        this.durationDialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new DurationDialog(this, {});
                jsDialog.setController(this.durationDialogController);
                ViewPU.create(jsDialog);
            },
            autoCancel: true
        }, this);
        this.intervalDialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new IntervalDialog(this, {});
                jsDialog.setController(this.intervalDialogController);
                ViewPU.create(jsDialog);
            },
            autoCancel: true
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.repeatDialogController !== undefined) {
            this.repeatDialogController = params.repeatDialogController;
        }
        if (params.reNameDialogController !== undefined) {
            this.reNameDialogController = params.reNameDialogController;
        }
        if (params.durationDialogController !== undefined) {
            this.durationDialogController = params.durationDialogController;
        }
        if (params.intervalDialogController !== undefined) {
            this.intervalDialogController = params.intervalDialogController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__settingInfo.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__settingInfo.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get settingInfo() {
        return this.__settingInfo.get();
    }
    set settingInfo(newValue) {
        this.__settingInfo.set(newValue);
    }
    showSettingDialog(sType) {
        switch (sType) {
            case AlarmSettingType.REPEAT:
                this.repeatDialogController.open();
                break;
            case AlarmSettingType.ALARM_NAME:
                this.reNameDialogController.open();
                break;
            case AlarmSettingType.RING_DURATION:
                this.durationDialogController.open();
                break;
            case AlarmSettingType.INTERVAL:
                this.intervalDialogController.open();
                break;
            default:
                break;
        }
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/Detail/SettingItem.ets(65:5)");
            Column.margin({
                bottom: 12,
                left: 12,
                right: 12
            });
            Column.borderRadius(24);
            Column.backgroundColor(Color.White);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Divider.create();
                    Divider.debugLine("view/Detail/SettingItem.ets(67:9)");
                    Divider.visibility(index === 0 ? Visibility.Hidden : Visibility.Visible);
                    Divider.opacity({ "id": 16777254, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                    Divider.color({ "id": 16777461, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                    Divider.lineCap(LineCapStyle.Round);
                    Divider.margin({
                        left: 12,
                        right: 12
                    });
                    if (!isInitialRender) {
                        Divider.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("view/Detail/SettingItem.ets(76:9)");
                    Row.height(56);
                    Row.alignItems(VerticalAlign.Center);
                    Row.padding({
                        left: 12,
                        right: 12
                    });
                    Row.onClick(() => {
                        this.showSettingDialog(item.sType);
                    });
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(item.title);
                    Text.debugLine("view/Detail/SettingItem.ets(77:11)");
                    Text.fontSize(16);
                    Text.fontWeight(FontWeight.Regular);
                    Text.fontColor({ "id": 16777461, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                    Text.layoutWeight(CommonConstants.DEFAULT_LAYOUT_WEIGHT);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(item.content);
                    Text.debugLine("view/Detail/SettingItem.ets(82:11)");
                    Text.fontSize(14);
                    Text.fontWeight(FontWeight.Normal);
                    Text.fontColor({ "id": 16777461, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                    Text.opacity({ "id": 16777267, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create({ "id": 16777489, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                    Image.debugLine("view/Detail/SettingItem.ets(87:11)");
                    Image.width(6.7);
                    Image.height(12.8);
                    Image.objectFit(ImageFit.Fill);
                    Image.margin({
                        left: 7
                    });
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.settingInfo, forEachItemGenFunction, (item, index) => JSON.stringify(item) + index, true, true);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=SettingItem.js.map