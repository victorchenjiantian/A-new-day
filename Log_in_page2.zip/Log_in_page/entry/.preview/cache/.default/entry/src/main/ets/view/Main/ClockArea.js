/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { CommonConstants } from '@bundle:com.example.log_in_page/entry/ets/common/constants/CommonConstants2';
import MainModel from '@bundle:com.example.log_in_page/entry/ets/viewmodel/MainViewModel2';
import { MainConstant } from '@bundle:com.example.log_in_page/entry/ets/common/constants/MainConstant';
export default class ClockArea extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.mainModel = MainModel.instant;
        this.drawInterval = CommonConstants.DEFAULT_NUMBER_NEGATIVE;
        this.__showClock = new ObservedPropertySimplePU(true, this, "showClock");
        this.canvasSize = 252;
        this.clockRadius = this.canvasSize / CommonConstants.DEFAULT_DOUBLE - CommonConstants.DEFAULT_DOUBLE;
        this.settings = new RenderingContextSettings(true);
        this.renderContext = new CanvasRenderingContext2D(this.settings);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.mainModel !== undefined) {
            this.mainModel = params.mainModel;
        }
        if (params.drawInterval !== undefined) {
            this.drawInterval = params.drawInterval;
        }
        if (params.showClock !== undefined) {
            this.showClock = params.showClock;
        }
        if (params.canvasSize !== undefined) {
            this.canvasSize = params.canvasSize;
        }
        if (params.clockRadius !== undefined) {
            this.clockRadius = params.clockRadius;
        }
        if (params.settings !== undefined) {
            this.settings = params.settings;
        }
        if (params.renderContext !== undefined) {
            this.renderContext = params.renderContext;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__showClock.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__showClock.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get showClock() {
        return this.__showClock.get();
    }
    set showClock(newValue) {
        this.__showClock.set(newValue);
    }
    aboutToDisappear() {
        clearInterval(this.drawInterval);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Canvas.create(this.renderContext);
            Canvas.debugLine("view/Main/ClockArea.ets(38:5)");
            Canvas.width(this.canvasSize);
            Canvas.aspectRatio(CommonConstants.DEFAULT_LAYOUT_WEIGHT);
            Canvas.onReady(() => {
                if (this.drawInterval === CommonConstants.DEFAULT_NUMBER_NEGATIVE) {
                    this.startDrawTask();
                }
            });
            Canvas.onClick(() => {
                this.showClock = !this.showClock;
            });
            if (!isInitialRender) {
                Canvas.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Canvas.pop();
    }
    // 启动绘画任务
    startDrawTask() {
        let that = this;
        that.renderContext.translate(this.canvasSize / CommonConstants.DEFAULT_DOUBLE, this.canvasSize / CommonConstants.DEFAULT_DOUBLE);
        that.drawClockArea();
        this.drawInterval = setInterval(() => {
            that.drawClockArea();
        }, MainConstant.DEFAULT_ONE_SECOND_MS);
    }
    // 开始绘制时钟区域
    drawClockArea() {
        this.renderContext.clearRect(-this.canvasSize, -this.canvasSize / CommonConstants.DEFAULT_DOUBLE, this.canvasSize * CommonConstants.DEFAULT_DOUBLE, this.canvasSize);
        let date = new Date();
        let hours = date.getHours();
        let minutes = date.getMinutes();
        let seconds = date.getSeconds();
        if (this.showClock) {
            this.drawPan();
            this.drawPointer(CommonConstants.DEFAULT_INTERVAL_MINUTE_MAX * (hours > CommonConstants.DEFAULT_TOTAL_HOUR
                ? hours - CommonConstants.DEFAULT_TOTAL_HOUR
                : hours)
                + minutes / CommonConstants.DEFAULT_TOTAL_HOUR * CommonConstants.DEFAULT_COMMON_DEGREE, MainConstant.HOUR_POINTER_IMAGE_URL);
            this.drawPointer(CommonConstants.DEFAULT_COMMON_DEGREE * minutes, MainConstant.MINUTE_POINTER_IMAGE_URL);
            this.drawPointer(CommonConstants.DEFAULT_COMMON_DEGREE * seconds, MainConstant.SECOND_POINTER_IMAGE_URL);
        }
        else {
            this.drawTime(hours, minutes, seconds);
        }
    }
    // 绘制表盘
    drawPan() {
        this.renderContext.beginPath();
        let secondImg = new ImageBitmap(MainConstant.CLOCK_PAN_IMAGE_URL);
        let imgWidth = this.clockRadius * 2;
        this.renderContext.drawImage(secondImg, -this.clockRadius, -this.clockRadius, imgWidth, imgWidth);
        this.renderContext.restore();
    }
    // 绘制时针、分针、秒针
    drawPointer(degree, pointerImgRes) {
        this.renderContext.save();
        let theta = (degree + MainConstant.DEFAULT_HORIZONTAL_ANGLE) * Math.PI / MainConstant.DEFAULT_HORIZONTAL_ANGLE;
        this.renderContext.rotate(theta);
        this.renderContext.beginPath();
        let secondImg = new ImageBitmap(pointerImgRes);
        let imgWidth = CommonConstants.DEFAULT_POINTER_WIDTH;
        this.renderContext.drawImage(secondImg, -imgWidth / CommonConstants.DEFAULT_DOUBLE, -this.clockRadius, imgWidth, this.clockRadius * CommonConstants.DEFAULT_DOUBLE);
        this.renderContext.restore();
    }
    // 绘制完整时间回显
    drawTime(hour, minute, second) {
        let time = this.mainModel.fillZero(hour)
            + MainConstant.DEFAULT_STRING_COLON
            + this.mainModel.fillZero(minute)
            + MainConstant.DEFAULT_STRING_COLON
            + this.mainModel.fillZero(second);
        this.renderContext.save();
        this.renderContext.font = 60
            + MainConstant.CLOCK_TIME_FONT_SIZE_UNIT;
        this.renderContext.beginPath();
        this.renderContext.textAlign = 'center';
        this.renderContext.fillText(time, 0, 0);
        this.renderContext.restore();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new ClockArea(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=ClockArea.js.map