/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { DetailConstant } from '@bundle:com.example.log_in_page/entry/ets/common/constants/DetailConstant';
import { CommonConstants } from '@bundle:com.example.log_in_page/entry/ets/common/constants/CommonConstants2';
export default class DatePickArea extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.Center });
            Stack.debugLine("view/detail/DatePickArea.ets(24:5)");
            Stack.height(200);
            Stack.padding({
                left: 24,
                right: 24
            });
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/detail/DatePickArea.ets(25:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    TextPicker.create({ range: item.data, selected: item.delSelect });
                    TextPicker.debugLine("view/detail/DatePickArea.ets(27:11)");
                    TextPicker.layoutWeight(CommonConstants.DEFAULT_LAYOUT_WEIGHT);
                    TextPicker.backgroundColor({ "id": 16777462, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                    TextPicker.onChange((value, index) => {
                        item.delSelect = index;
                    });
                    if (!isInitialRender) {
                        TextPicker.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                TextPicker.pop();
            };
            this.forEachUpdateFunction(elmtId, DetailConstant.DAY_DATA, forEachItemGenFunction, (item) => JSON.stringify(item), false, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Row.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=DatePickArea.js.map