/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import MainModel from '@bundle:com.example.log_in_page/entry/ets/viewmodel/MainViewModel2';
import { CommonConstants } from '@bundle:com.example.log_in_page/entry/ets/common/constants/CommonConstants2';
import AlarmItem from '@bundle:com.example.log_in_page/entry/ets/viewmodel/AlarmItem';
export default class AlarmListItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.mainModel = MainModel.instant;
        this.alarmItem = new AlarmItem();
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.mainModel !== undefined) {
            this.mainModel = params.mainModel;
        }
        if (params.alarmItem !== undefined) {
            this.alarmItem = params.alarmItem;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/Main/AlarmListItem.ets(27:5)");
            Row.padding({
                left: 12,
                right: 12
            });
            Row.width(CommonConstants.FULL_LENGTH);
            Row.height(72);
            Row.backgroundColor(Color.White);
            Row.borderRadius(24);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/Main/AlarmListItem.ets(28:7)");
            Column.width(CommonConstants.FULL_LENGTH);
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(CommonConstants.DEFAULT_LAYOUT_WEIGHT);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/Main/AlarmListItem.ets(29:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.mainModel.getNoonContent(this.alarmItem.hour));
            Text.debugLine("view/Main/AlarmListItem.ets(30:11)");
            __Text__CommonTextAttr(16, FontWeight.Regular);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.mainModel.getTaskTimeContent(this.alarmItem.hour, this.alarmItem.minute));
            Text.debugLine("view/Main/AlarmListItem.ets(33:11)");
            __Text__CommonTextAttr(24, FontWeight.Regular, { left: 4 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.mainModel.getDescContent(ObservedObject.GetRawObject(this.alarmItem)));
            Text.debugLine("view/Main/AlarmListItem.ets(39:9)");
            __Text__CommonTextAttr(14, FontWeight.Normal, { top: 2 }, { "id": 16777229, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Toggle.create({ type: ToggleType.Switch, isOn: this.alarmItem.isOpen });
            Toggle.debugLine("view/Main/AlarmListItem.ets(49:7)");
            Toggle.onChange((isOn) => {
                this.mainModel.openAlarm(this.alarmItem.id, isOn);
            });
            Toggle.width(36);
            Toggle.height(20);
            if (!isInitialRender) {
                Toggle.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Toggle.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __Text__CommonTextAttr(fontSize, fontWeight, margin, opacity) {
    Text.fontColor({ "id": 16777461, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
    Text.fontSize(fontSize);
    Text.fontWeight(fontWeight);
    Text.margin(margin != undefined ? margin : 0);
    Text.opacity(opacity != undefined ? opacity : 1);
}
//# sourceMappingURL=AlarmListItem.js.map