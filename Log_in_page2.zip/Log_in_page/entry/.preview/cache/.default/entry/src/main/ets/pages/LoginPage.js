/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import prompt from '@ohos:promptAction';
import router from '@ohos:router';
import CommonConstants from '@bundle:com.example.log_in_page/entry/ets/common/constants/CommonConstants';
function __TextInput__inputStyle() {
    TextInput.placeholderColor({ "id": 16777474, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
    TextInput.height({ "id": 16777313, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
    TextInput.fontSize({ "id": 16777287, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
    TextInput.backgroundColor({ "id": 16777458, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
    TextInput.width(CommonConstants.FULL_PARENT);
    TextInput.padding({ left: CommonConstants.INPUT_PADDING_LEFT });
    TextInput.margin({ top: { "id": 16777307, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
}
function __Line__lineStyle() {
    Line.width(CommonConstants.FULL_PARENT);
    Line.height({ "id": 16777308, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
    Line.backgroundColor({ "id": 16777465, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
}
function __Text__blueTextStyle() {
    Text.fontColor({ "id": 16777467, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
    Text.fontSize({ "id": 16777357, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
    Text.fontWeight(FontWeight.Medium);
}
class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__account = new ObservedPropertySimplePU('', this, "account");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__isShowProgress = new ObservedPropertySimplePU(false, this, "isShowProgress");
        this.timeOutId = -1;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.account !== undefined) {
            this.account = params.account;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.isShowProgress !== undefined) {
            this.isShowProgress = params.isShowProgress;
        }
        if (params.timeOutId !== undefined) {
            this.timeOutId = params.timeOutId;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__account.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__isShowProgress.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__account.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__isShowProgress.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get account() {
        return this.__account.get();
    }
    set account(newValue) {
        this.__account.set(newValue);
    }
    get password() {
        return this.__password.get();
    }
    set password(newValue) {
        this.__password.set(newValue);
    }
    get isShowProgress() {
        return this.__isShowProgress.get();
    }
    set isShowProgress(newValue) {
        this.__isShowProgress.set(newValue);
    }
    imageButton(src, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("pages/LoginPage.ets(54:5)");
            Button.height({ "id": 16777331, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.width({ "id": 16777331, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.backgroundColor({ "id": 16777458, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(src);
            Image.debugLine("pages/LoginPage.ets(55:7)");
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
    }
    login() {
        if (this.account === '' || this.password === '') {
            prompt.showToast({
                message: { "id": 16777386, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }
            });
        }
        else if (false) {
            prompt.showToast({
                message: { "id": 16777385, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }
            });
        }
        else {
            //this.isShowProgress = true;
            prompt.showToast({
                message: { "id": 16777437, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }
            });
            if (this.timeOutId === -1) {
                this.timeOutId = setTimeout(() => {
                    //this.isShowProgress = false;
                    //this.timeOutId = -1;
                    console.info(`pages/MainPage`);
                    router.pushUrl({ url: 'pages/MainPage' }).then(() => {
                        console.info('Succeeded in jumping to the second page.');
                    }).catch((err) => {
                        console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`);
                    });
                }, CommonConstants.LOGIN_DELAY_TIME);
            }
        }
    }
    Register() {
        /*this.isShowProgress = true;
        if (this.timeOutId === -1) {*/
        prompt.showToast({
            message: { "id": 16777437, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }
        });
        this.timeOutId = setTimeout(() => {
            /*this.isShowProgress = false;
            this.timeOutId = -1;*/
            console.info(`pages/RegisterPage`);
            router.pushUrl({ url: 'pages/RegisterPage' }).then(() => {
                console.info('Succeeded in jumping to the second page.');
            }).catch((err) => {
                console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`);
            });
        }, CommonConstants.LOGIN_DELAY_TIME);
        //}
    }
    aboutToDisappear() {
        clearTimeout(this.timeOutId);
        this.timeOutId = -1;
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/LoginPage.ets(122:5)");
            Column.backgroundImage({ "id": 16777492, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Column.backgroundImageSize({
                height: '100%'
            });
            Column.height(CommonConstants.FULL_PARENT);
            Column.width(CommonConstants.FULL_PARENT);
            Column.padding({
                left: { "id": 16777334, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" },
                right: { "id": 16777334, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" },
                bottom: { "id": 16777316, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777222, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Image.debugLine("pages/LoginPage.ets(123:7)");
            Image.width(80);
            Image.height(80);
            Image.borderRadius(50);
            Image.margin({
                top: "120vp"
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777389, "type": 10003, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Text.debugLine("pages/LoginPage.ets(130:7)");
            Text.fontSize({ "id": 16777335, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor({ "id": 16777479, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("欢迎登录 A New Day");
            Text.debugLine("pages/LoginPage.ets(134:7)");
            Text.fontColor(Color.Gray);
            Text.fontSize(14);
            Text.margin({
                top: '15vp'
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/LoginPage.ets(140:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '  请输入用户名' });
            TextInput.debugLine("pages/LoginPage.ets(143:7)");
            TextInput.onChange((value) => {
                this.account = value;
            });
            TextInput.margin({ bottom: '10vp' });
            TextInput.type(InputType.Password);
            TextInput.maxLength(CommonConstants.INPUT_ACCOUNT_LENGTH);
            __TextInput__inputStyle();
            TextInput.onChange((value) => {
                this.account = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '  请输入密码' });
            TextInput.debugLine("pages/LoginPage.ets(155:7)");
            TextInput.onChange((value) => {
                this.password = value;
            });
            TextInput.type(InputType.Password);
            TextInput.maxLength(CommonConstants.INPUT_PASSWORD_LENGTH);
            __TextInput__inputStyle();
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/LoginPage.ets(163:7)");
            Row.margin({ top: 10 });
            Row.width("100%");
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("短信验证码");
            Text.debugLine("pages/LoginPage.ets(164:9)");
            Text.fontColor("#007DFF");
            Text.fontSize(12);
            Text.margin({ left: 5 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("忘记密码");
            Text.debugLine("pages/LoginPage.ets(167:9)");
            Text.fontColor("#007DFF");
            Text.fontSize(12);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("登录", { type: ButtonType.Capsule });
            Button.debugLine("pages/LoginPage.ets(172:7)");
            Button.width(CommonConstants.BUTTON_WIDTH);
            Button.height({ "id": 16777310, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.fontSize({ "id": 16777330, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.fontWeight(FontWeight.Medium);
            Button.backgroundColor({ "id": 16777468, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.margin({ top: { "id": 16777312, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, bottom: { "id": 16777311, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
            Button.onClick(() => {
                this.login();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("注册账号", { type: ButtonType.Capsule });
            Button.debugLine("pages/LoginPage.ets(182:7)");
            Button.width(CommonConstants.BUTTON_WIDTH);
            Button.height({ "id": 16777310, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.fontSize({ "id": 16777330, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.fontWeight(FontWeight.Medium);
            Button.backgroundColor({ "id": 16777468, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Button.margin({ top: { "id": 16777286, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, bottom: { "id": 16777311, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
            Button.onClick(() => {
                this.Register();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            /*Text($r('app.string.register_account'))
              .fontColor($r('app.color.login_blue_text_color'))
              .fontSize($r('app.float.normal_text_size'))
              .fontWeight(FontWeight.Medium)*/
            if (this.isShowProgress) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        LoadingProgress.create();
                        LoadingProgress.debugLine("pages/LoginPage.ets(198:9)");
                        LoadingProgress.color({ "id": 16777466, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                        LoadingProgress.width({ "id": 16777318, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                        LoadingProgress.height({ "id": 16777318, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
                        LoadingProgress.margin({ top: { "id": 16777317, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
                        if (!isInitialRender) {
                            LoadingProgress.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/LoginPage.ets(205:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("其他登录方式");
            Text.debugLine("pages/LoginPage.ets(206:7)");
            Text.fontColor({ "id": 16777473, "type": 10001, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Text.backgroundColor(Color.White);
            Text.fontSize({ "id": 16777309, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Text.fontWeight(FontWeight.Medium);
            Text.margin({ top: { "id": 16777333, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" }, bottom: { "id": 16777332, "type": 10002, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" } });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: CommonConstants.LOGIN_METHODS_SPACE });
            Row.debugLine("pages/LoginPage.ets(212:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/LoginPage.ets(213:9)");
            Button.backgroundColor(Color.Transparent);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777490, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Image.debugLine("pages/LoginPage.ets(214:11)");
            Image.width(35);
            Image.height(35);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/LoginPage.ets(217:9)");
            Button.backgroundColor(Color.Transparent);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777454, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Image.debugLine("pages/LoginPage.ets(218:11)");
            Image.width(35);
            Image.height(35);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/LoginPage.ets(221:9)");
            Button.backgroundColor(Color.Transparent);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777284, "type": 20000, params: [], "bundleName": "com.example.log_in_page", "moduleName": "entry" });
            Image.debugLine("pages/LoginPage.ets(222:11)");
            Image.width(35);
            Image.height(35);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new LoginPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=LoginPage.js.map