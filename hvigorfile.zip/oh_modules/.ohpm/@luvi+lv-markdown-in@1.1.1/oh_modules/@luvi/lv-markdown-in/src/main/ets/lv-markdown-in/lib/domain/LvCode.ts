type Theme = "light" | "dark"

class LvCode {
  private theme: Theme = "dark"

  setTheme(value: Theme){
    this.theme = value
  }

  getTheme(): string{
    return this.theme
  }
}

const lvCode = new LvCode()
export { lvCode }