class LvQuote {
  private backgroundColor: string = "rgba(234, 239, 255, 0.62)"
  private borderColor: string = "#409EFF"

  setBackgroundColor(value: string){
    this.backgroundColor = value
  }

  setBorderColor(value: string){
    this.borderColor = value
  }

  getBackgroundColor(): string {
    return this.backgroundColor
  }

  getBorderColor(): string {
    return this.borderColor
  }
}

const lvQuote= new LvQuote()
export { lvQuote }