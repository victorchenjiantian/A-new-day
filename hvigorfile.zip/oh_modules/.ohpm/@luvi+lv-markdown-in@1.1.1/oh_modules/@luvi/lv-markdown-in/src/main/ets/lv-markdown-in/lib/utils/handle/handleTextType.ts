import { LV_TEXT_TYPE, SP_TYPE } from '../constant'

export default function handleTextType(text: string): string[] {
  let res: string
  let SPK = SP_TYPE.SPK
  let SPL_S = SP_TYPE.SPL
  res = text.replace(/\*\*(.*?)\*\*/g, `${SPK}${LV_TEXT_TYPE.L_BOLD}${SPL_S}$1${SPK}`)
  res = res.replace(/__(.*?)__/g, `${SPK}${LV_TEXT_TYPE.L_BOLD}${SPL_S}$1${SPK}`)
  res = res.replace(/\*(.*?)\*/g, `${SPK}${LV_TEXT_TYPE.L_ITALIC}${SPL_S}$1${SPK}`)
  res = res.replace(/_(.*?)_/g, `${SPK}${LV_TEXT_TYPE.L_ITALIC}${SPL_S}$1${SPK}`)
  res = res.replace(/==(.*?)==/g, `${SPK}${LV_TEXT_TYPE.L_MARK}${SPL_S}$1${SPK}`)
  res = res.replace(/\~\~(.*?)\~\~/g, `${SPK}${LV_TEXT_TYPE.L_DEL}${SPL_S}$1${SPK}`)
  res = res.replace(/\`(.*?)\`/g, `${SPK}${LV_TEXT_TYPE.L_PINK}${SPL_S}$1${SPK}`)
  let result: string[] = res.split(SPK)
  return result
}