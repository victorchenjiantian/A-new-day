class LvTitle {
  private level1Title: number | string = 32
  private level2Title: number | string = 29
  private level3Title: number | string = 26
  private level4Title: number | string = 23
  private level5Title: number | string = 20
  private level6Title: number | string = 17
  private levelTitleColor: string = "#303133"

  setLevel1Title(value: number | string) {
    this.level1Title = value
  }

  setLevel2Title(value: number | string) {
    this.level2Title = value
  }

  setLevel3Title(value: number | string) {
    this.level3Title = value
  }

  setLevel4Title(value: number | string) {
    this.level4Title = value
  }

  setLevel5Title(value: number | string) {
    this.level5Title = value
  }

  setLevel6Title(value: number | string) {
    this.level6Title = value
  }

  setLevelTitleColor(value: string) {
    this.levelTitleColor = value
  }

  getLevel1Title(): number | string {
    return this.level1Title
  }

  getLevel2Title(): number | string {
    return this.level2Title
  }

  getLevel3Title(): number | string {
    return this.level3Title
  }

  getLevel4Title(): number | string {
    return this.level4Title
  }

  getLevel5Title(): number | string {
    return this.level5Title
  }

  getLevel6Title(): number | string {
    return this.level6Title
  }

  getLevelTitleColor(): string {
    return this.levelTitleColor
  }
}

const lvTitle = new LvTitle()
export { lvTitle }