class LvImage {
  private imgWidth: number | string = "60%"
  private imgHeight: number | string | null = null
  private confGlobal: boolean = false

  setImgWidth(value: string){
    this.imgWidth = value
  }

  setImgHeight(value: string){
    this.imgHeight = value
  }

  setConfGlobal(value: boolean){
    this.confGlobal = value
  }

  getImgWidth(): number | string {
    return this.imgWidth
  }

  getImgHeight(): number | string | null {
    return this.imgHeight
  }

  getConfGlobal(): boolean {
    return this.confGlobal
  }
}

const lvImage = new LvImage()
export { lvImage }