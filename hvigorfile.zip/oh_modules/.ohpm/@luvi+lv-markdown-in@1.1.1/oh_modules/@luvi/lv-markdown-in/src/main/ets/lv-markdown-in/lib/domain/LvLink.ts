class LvLink {
  private textSize: number | string = 15
  private textColor: string = "#3A8AEB"
  private textUnderline: boolean = false

  setTextSize(value: number | string) {
    this.textSize = value
  }

  setTextColor(value: string) {
    this.textColor = value
  }

  setTextUnderline(value: boolean) {
    this.textUnderline = value
  }

  getTextSize(): number | string {
    return this.textSize
  }

  getTextColor(): string {
    return this.textColor
  }

  getTextUnderline(): boolean {
    return this.textUnderline
  }

}

const lvLink = new LvLink()
export { lvLink }