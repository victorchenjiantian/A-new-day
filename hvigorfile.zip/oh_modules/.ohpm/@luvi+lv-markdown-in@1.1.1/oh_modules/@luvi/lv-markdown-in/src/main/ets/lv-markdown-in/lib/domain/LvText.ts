class Text {
  private textSize: number | string = 15
  private textColor: string = "#303133"
  private textMarkBackground: string = "#ffffd3b8"

  setTextSize(value: number | string) {
    this.textSize = value
  }

  setTextColor(value: string) {
    this.textColor = value
  }

  setTextMarkBackground(value: string) {
    this.textMarkBackground = value
  }

  getTextSize(): number | string {
    return this.textSize
  }

  getTextColor(): string {
    return this.textColor
  }

  getTextMarkBackground(): string {
    return this.textMarkBackground
  }

}

const lvText = new Text()
export { lvText }